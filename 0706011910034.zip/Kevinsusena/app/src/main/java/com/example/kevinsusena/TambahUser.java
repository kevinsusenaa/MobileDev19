package com.example.kevinsusena;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.kevinsusena.model.MainActivity;
import com.example.kevinsusena.model.Data;
import com.example.kevinsusena.model.Users;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;

public class TambahUser extends AppCompatActivity implements TextWatcher {


    TextInputLayout masuk_nama, masuk_umur, masuk_alamat;
    TextInputEditText tulisan_nama, tulisan_umur,tulisan_alamat;
    Button button_tambah;
    Toolbar toolbar;
    String nama, umur, alamat;
    ProgressDialog progressDialog;

    boolean edit = false;
    int home = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_user);

        toolbar = findViewById(R.id.toolbar3);
        masuk_nama = findViewById(R.id.masuk_nama);
        masuk_umur = findViewById(R.id.masuk_umur);
        masuk_alamat = findViewById(R.id.tampilan_alamat);
        button_tambah = findViewById(R.id.button_tambah);

        tulisan_nama = findViewById(R.id.tulisan_nama);
        tulisan_umur = findViewById(R.id.tulisan_umur);
        tulisan_alamat = findViewById(R.id.tulisan_alamat);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(TambahUser.this, MainActivity.class);
                home = 0;
                startActivity(intent);
                finish();
            }
        });

        final int position = getIntent().getIntExtra("position", 0);
        ArrayList<Users> arrayList = Data.dataUser;
        final int check_edit = getIntent().getIntExtra("check_edit", 0);


        if(check_edit == 0){
            System.out.println("error");
            toolbar.setTitle("Add User");
        }else{
            tulisan_nama.setText(arrayList.get(position).getNama());
            tulisan_umur.setText(arrayList.get(position).getUmur());
            tulisan_alamat.setText(arrayList.get(position).getAlamat());
            edit = true;
            toolbar.setTitle("Edit User");
        }

        masuk_nama.getEditText().addTextChangedListener(this);
        masuk_umur.getEditText().addTextChangedListener(this);
        masuk_alamat.getEditText().addTextChangedListener(this);

        button_tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog = new ProgressDialog(TambahUser.this);
                progressDialog.setMessage("Tunggu...");
                progressDialog.setTitle("ProgressDialog");
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressDialog.show();
                progressDialog.setCancelable(false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(10000);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        progressDialog.dismiss();
                    }
                }).start();
                Users user = new Users(nama, umur, alamat);
                Intent intent = new Intent(TambahUser.this, MainActivity.class);
                if(edit == true){
                    intent = new Intent(TambahUser.this, UserInfo.class);
                }
                intent.putExtra("dataUser", user);
                if(edit == false){
                    Data.dataUser.add(user);
                }else{
                    Data.dataUser.set(position, user);
                }
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        nama = masuk_nama.getEditText().getText().toString().trim();
        umur = masuk_umur.getEditText().getText().toString().trim();
        alamat = masuk_alamat.getEditText().getText().toString().trim();
        if (!nama.isEmpty() && !umur.isEmpty() && !alamat.isEmpty()) {
            button_tambah.setEnabled(true);
        } else {

            button_tambah.setEnabled(false);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }

    @Override
    public void onStop() {

        super.onStop();
        if (home == 1){
            progressDialog.dismiss();
        }
    }
}

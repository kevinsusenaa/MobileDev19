package com.example.kevinsusena.model;

import java.util.ArrayList;

public class Data {

    public static ArrayList<Users> dataUser = new ArrayList<>();
}

package com.example.kevinsusena;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.kevinsusena.model.Users;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder>{

    ArrayList<Users> arrayList;
    private OnCardListener mOnCardListener;

    public Adapter(ArrayList<Users> users, OnCardListener onCardListener){
        this.arrayList = users;
        this.mOnCardListener = onCardListener;
    }

    public ArrayList<Users> getArrayList() {
        return arrayList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview, parent, false);
        return new MyViewHolder(view, mOnCardListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name.setText(arrayList.get(position).getNama());
        holder.age.setText(arrayList.get(position).getUmur() + " tahun");
        holder.address.setText(arrayList.get(position).getAlamat());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public TextView name, age, address;
        OnCardListener onCardListener;

        public MyViewHolder(@NonNull View itemView, OnCardListener onCardListener) {
            super(itemView);
            name = itemView.findViewById(R.id.tampilan_nama);
            age = itemView.findViewById(R.id.tampilan_umur);
            address = itemView.findViewById(R.id.tampilan_alamat);
            this.onCardListener = onCardListener;

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            onCardListener.onCardClick(getAdapterPosition());
        }
    }

    public interface OnCardListener {
        void onCardClick (int position);
    }
}
